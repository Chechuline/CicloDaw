window.onload=function(){
    figuritasApp.main();
}
